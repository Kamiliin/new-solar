
const productos =

[
    {
        id: 1,
        nombre: "Kit Solar 3.4 kw ON GRID",
        imagen: '../img/ofertas-07.jpg',
        desc: "6 – Paneles solares Fotovoltaico DHA Solar 500w\n1 – Inversor 3.4 kw Ultima Generación\n- Instalación llave en mano\n- Certificación TE4 Incluida\n- Garantía con proveedores"
    },
    {
        id: 2,
        nombre: "Kit Solar 5 kw ON GRID",
        imagen: '../img/ofertas-08.jpg',
        desc: "10– Paneles solares Fotovoltaico DHA Solar 500w\n1 – Inversor 5 kw Ultima Generación\n- Instalación llave en mano\n- Certificación TE4 Incluida\n- Garantía con proveedores"
    },
    {
        id: 3,
        nombre: "Kit Solar 10 kW ON GRID",
        imagen: '../img/ofertas-06.jpg',
        desc: "Este kit solar ON GRID de 10 kW incluye:\n- 20 Paneles solares Fotovoltaicos DHA Solar de 500W\n- 2 Inversores de 5 kW de última generación\n- Instalación llave en mano\n- Certificación TE4 incluida\n- Garantía con proveedores"
    },

    {
        id: 4,
        nombre: "Kit Solar 5 kW HÍBRIDO",
        imagen: '../img/ofertas-05.jpg',
        desc: "Este kit solar HÍBRIDO de 5 kW incluye:\n- 10 Paneles solares Fotovoltaicos DHA Solar de 500W\n- 1 Inversor Híbrido de 5 kW de última generación\n- 1 Batería de litio de última generación\n- Instalación llave en mano\n- Garantía con proveedores"
    },
    {
        id: 5,
        nombre: "Kit Solar 3 kW OFF GRID",
        imagen: '../img/ofertas-04.jpg',
        desc: "Este kit solar OFF GRID de 3 kW incluye:\n- 5 Paneles solares Fotovoltaicos DHA Solar de 500W\n- 1 Inversor OFFGRID de 3 kW de última generación\n- 1 Batería de litio de última generación con capacidad de 3000 Wh\n- Instalación llave en mano\n- Garantía con proveedores"
    },
    {
        id: 6,
        nombre: "Kit Solar OFF GRID con Batería de Litio",
        imagen: '../img/ofertas-03.jpg',
        desc: "Este kit solar OFF GRID con batería de litio incluye:\n- 6 Paneles solares Fotovoltaicos DHA Solar de 500W\n- 1 Inversor OFFGRID de 5 kW de última generación\n- 1 Batería de litio de última generación con capacidad de 5000 Wh\n- Instalación llave en mano\n- Garantía con proveedores"
    },
    {
        id: 7,
        nombre: "Kit Solar 6 kW OFF GRID",
        imagen: '../img/ofertas-02.jpg',
        desc: "Este kit solar OFF GRID de 6 kW incluye:\n- 7 Paneles solares Fotovoltaicos DHA Solar de 500W\n- 1 Inversor OFFGRID de 6 kW de última generación\n- 1 Batería de litio de última generación con capacidad de 5000 Wh\n- Instalación llave en mano\n- Garantía con proveedores"
    },
    {
        id: 8,
        nombre: "Kit Solar 10 kW OFF GRID",
        imagen: '../img/ofertas-01.jpg',
        desc: "Este kit solar OFF GRID de 10 kW incluye:\n- 15 Paneles solares Fotovoltaicos DHA Solar de 500W\n- 1 Inversor OFFGRID de 10 kW de última generación\n- 2 Baterías de litio de última generación con capacidad de 5000 Wh cada una\n- Instalación llave en mano\n- Garantía con proveedores"
    }
    
    
    

    
    

    
]



